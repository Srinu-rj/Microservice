package com.order.orderdeatels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderDeatelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
