package com.address.address;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
